# KidsPlay - PRD (aggiornato)

## Obiettivo
Sviluppare un'app educativa e di intrattenimento con minigiochi semplici, sicuri e adatti a bambini.

## Funzionalità Principali
- Raccolta di minigiochi (memoria, puzzle, riconoscimento forme/colori).
- Interfaccia touch intuitiva e sicura.
- Modalità offline per giocare senza internet.
- Sistema premi (adesivi virtuali, medaglie).
- Sezione genitori con statistiche e controlli.

## Supporto Gamepad/Joystick
- L’app deve supportare controller esterni compatibili con lo standard HID (PlayStation DualShock/DualSense, Xbox Controller, Amazon Luna).
- L’input dei gamepad viene gestito tramite plugin Flutter (`gamepads`) e mappato in azioni di gioco (muovi, seleziona, annulla).
- Dev’essere presente un menu per la rimappatura dei comandi, in modo che genitori/tutori possano adattare i pulsanti alle preferenze del bambino.
- Ogni minigioco deve poter essere controllato sia tramite touch che tramite gamepad, garantendo accessibilità universale.
- Test richiesti su:
  - Android (con controller Bluetooth e USB OTG)
  - Desktop (Windows/macOS con controller USB/Bluetooth)
